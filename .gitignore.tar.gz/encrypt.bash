#!/bin/bash

printf 'password: ' && read -s

printf "$REPLY" | sha256sum | cut -d ' ' -f 1 > password.hash
openssl enc -aes-256-cbc -k "$REPLY" -in img.dd -out img.dd.enc
